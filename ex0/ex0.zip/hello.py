#############################################################
# FILE : hello.py
# WRITER : Raz Karl , razkarl , 311143127
# EXERCISE : intro2cs ex0 2016-2017
# DESCRIPTION: A simple program that prints "Hello World!" to
# the standard output (screen).
#############################################################
print("Hello World!")
