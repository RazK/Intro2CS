#!/usr/bin/env python3

from hello_turtle import draw_flower_bed
import turtle

if __name__=="__main__":
    draw_flower_bed()
    turtle.done()
